package com.example.jobtest.interfaces;

public interface IExecutable<Parameter> {
    void execute(Parameter parameter);
}
