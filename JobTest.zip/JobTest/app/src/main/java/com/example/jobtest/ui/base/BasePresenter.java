package com.example.jobtest.ui.base;

public interface BasePresenter {

    void onStart();
}
