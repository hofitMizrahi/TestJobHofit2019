package com.example.jobtest.interfaces;

public interface IExecuteItemClick {

    void onItemClick(int position);
}
