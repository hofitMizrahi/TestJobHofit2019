package com.example.jobtest.di.qualifire;

import javax.inject.Qualifier;

@Qualifier
public @interface ApplicationContext {
}
