package com.example.jobtest.ui.utils;

public class Constants {

    public static final String BASE_URL = "https://assets-production.applicaster.com/applicaster-employees/israel_team/Elad/assignment/";
    public static final int VIDEO_TYPE = 0;
    public static final int LINK_TYPE = 1;
}
